"""
URL configuration for photoalbum project.
"""

from django.contrib import admin
from django.urls import path, include
from albums.views import HomeView, SignUpView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', HomeView.as_view(), name='home'),
    path('signup/', SignUpView.as_view(), name='signup'),
    path('accounts/', include('django.contrib.auth.urls')),
    path('albums/', include('albums.urls')),
]
