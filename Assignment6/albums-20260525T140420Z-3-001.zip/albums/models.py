from django.db import models
from django.conf import settings
from django.urls import reverse
from cloudinary.models import CloudinaryField


class Album(models.Model):
    """
    Represents a photo album owned by a user.
    """
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True, default='')
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='albums',
    )
    cover_image = CloudinaryField(
        'cover',
        blank=True,
        null=True,
        folder='album_covers',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Album'
        verbose_name_plural = 'Albums'

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('album-detail', kwargs={'pk': self.pk})

    @property
    def photo_count(self):
        return self.photos.count()


class Photo(models.Model):
    """
    Represents a single photo within an album.
    Images are stored on Cloudinary.
    """
    album = models.ForeignKey(
        Album,
        on_delete=models.CASCADE,
        related_name='photos',
    )
    image = CloudinaryField(
        'photo',
        folder='album_photos',
    )
    caption = models.CharField(max_length=300, blank=True, default='')
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='photos',
    )
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-uploaded_at']
        verbose_name = 'Photo'
        verbose_name_plural = 'Photos'

    def __str__(self):
        return self.caption or f"Photo #{self.pk}"

    def get_absolute_url(self):
        return reverse('photo-detail', kwargs={'pk': self.pk})
