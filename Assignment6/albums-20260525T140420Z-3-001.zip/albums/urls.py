from django.urls import path
from . import views

urlpatterns = [
    # Album CRUD
    path('', views.AlbumListView.as_view(), name='album-list'),
    path('create/', views.AlbumCreateView.as_view(), name='album-create'),
    path('<int:pk>/', views.AlbumDetailView.as_view(), name='album-detail'),
    path('<int:pk>/edit/', views.AlbumUpdateView.as_view(), name='album-update'),
    path('<int:pk>/delete/', views.AlbumDeleteView.as_view(), name='album-delete'),

    # Photo CRUD
    path('<int:album_pk>/photos/add/', views.PhotoUploadView.as_view(), name='photo-upload'),
    path('photos/<int:pk>/', views.PhotoDetailView.as_view(), name='photo-detail'),
    path('photos/<int:pk>/delete/', views.PhotoDeleteView.as_view(), name='photo-delete'),
]
