"""
Class-Based Views for all CRUD operations.

All views use Django's generic CBVs with RBAC enforced via mixins.
"""

from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.messages.views import SuccessMessageMixin
from django.contrib import messages
from django.urls import reverse_lazy, reverse
from django.views.generic import (
    TemplateView,
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView,
)

from .models import Album, Photo
from .forms import AlbumForm, PhotoForm, SignUpForm
from .mixins import OwnerOrAdminRequiredMixin, AlbumOwnerOrAdminMixin


# =============================================================================
# PUBLIC VIEWS
# =============================================================================

class HomeView(TemplateView):
    """Landing page — public."""
    template_name = 'home.html'


# =============================================================================
# AUTHENTICATION VIEWS
# =============================================================================

class SignUpView(SuccessMessageMixin, CreateView):
    """User registration view."""
    form_class = SignUpForm
    template_name = 'registration/signup.html'
    success_url = reverse_lazy('login')
    success_message = "Account created successfully! Please log in."


# =============================================================================
# ALBUM VIEWS (CRUD)
# =============================================================================

class AlbumListView(LoginRequiredMixin, ListView):
    """List all albums. Logged-in users see all albums."""
    model = Album
    template_name = 'albums/album_list.html'
    context_object_name = 'albums'
    paginate_by = 12


class AlbumDetailView(LoginRequiredMixin, DetailView):
    """View a single album and its photos."""
    model = Album
    template_name = 'albums/album_detail.html'
    context_object_name = 'album'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['photos'] = self.object.photos.all()
        context['can_edit'] = (
            self.request.user == self.object.owner
            or self.request.user.is_staff
            or self.request.user.is_superuser
        )
        return context


class AlbumCreateView(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    """Create a new album. Any logged-in user can create albums."""
    model = Album
    form_class = AlbumForm
    template_name = 'albums/album_form.html'
    success_message = "Album '%(title)s' created successfully!"

    def form_valid(self, form):
        form.instance.owner = self.request.user
        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['form_title'] = 'Create New Album'
        context['submit_text'] = 'Create Album'
        return context


class AlbumUpdateView(OwnerOrAdminRequiredMixin, SuccessMessageMixin, UpdateView):
    """Update an existing album. Owner or Admin only."""
    model = Album
    form_class = AlbumForm
    template_name = 'albums/album_form.html'
    success_message = "Album '%(title)s' updated successfully!"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['form_title'] = 'Edit Album'
        context['submit_text'] = 'Save Changes'
        return context


class AlbumDeleteView(OwnerOrAdminRequiredMixin, DeleteView):
    """Delete an album. Owner or Admin only."""
    model = Album
    template_name = 'albums/album_confirm_delete.html'
    success_url = reverse_lazy('album-list')

    def delete(self, request, *args, **kwargs):
        album = self.get_object()
        messages.success(request, f"Album '{album.title}' deleted successfully.")
        return super().delete(request, *args, **kwargs)


# =============================================================================
# PHOTO VIEWS (CRUD)
# =============================================================================

class PhotoUploadView(AlbumOwnerOrAdminMixin, SuccessMessageMixin, CreateView):
    """Upload a photo to a specific album. Album owner or Admin only."""
    model = Photo
    form_class = PhotoForm
    template_name = 'albums/photo_form.html'
    success_message = "Photo uploaded successfully!"

    def form_valid(self, form):
        form.instance.album_id = self.kwargs['album_pk']
        form.instance.uploaded_by = self.request.user
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('album-detail', kwargs={'pk': self.kwargs['album_pk']})

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['album'] = Album.objects.get(pk=self.kwargs['album_pk'])
        return context


class PhotoDetailView(LoginRequiredMixin, DetailView):
    """View a single photo."""
    model = Photo
    template_name = 'albums/photo_detail.html'
    context_object_name = 'photo'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['can_edit'] = (
            self.request.user == self.object.uploaded_by
            or self.request.user == self.object.album.owner
            or self.request.user.is_staff
            or self.request.user.is_superuser
        )
        return context


class PhotoDeleteView(OwnerOrAdminRequiredMixin, DeleteView):
    """Delete a photo. Uploader, Album owner, or Admin only."""
    model = Photo
    template_name = 'albums/photo_confirm_delete.html'

    def get_success_url(self):
        return reverse('album-detail', kwargs={'pk': self.object.album.pk})

    def delete(self, request, *args, **kwargs):
        messages.success(request, "Photo deleted successfully.")
        return super().delete(request, *args, **kwargs)

    def test_func(self):
        """Override to also allow album owner to delete any photo in their album."""
        obj = self.get_object()
        user = self.request.user

        if user.is_staff or user.is_superuser:
            return True
        if obj.uploaded_by == user:
            return True
        if obj.album.owner == user:
            return True
        return False
