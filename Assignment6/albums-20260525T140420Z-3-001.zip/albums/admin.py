from django.contrib import admin
from .models import Album, Photo


class PhotoInline(admin.TabularInline):
    """Inline photo display within the Album admin."""
    model = Photo
    extra = 0
    readonly_fields = ('uploaded_by', 'uploaded_at')


@admin.register(Album)
class AlbumAdmin(admin.ModelAdmin):
    list_display = ('title', 'owner', 'photo_count', 'created_at', 'updated_at')
    list_filter = ('created_at', 'owner')
    search_fields = ('title', 'description', 'owner__username')
    readonly_fields = ('created_at', 'updated_at')
    inlines = [PhotoInline]


@admin.register(Photo)
class PhotoAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'album', 'uploaded_by', 'uploaded_at')
    list_filter = ('uploaded_at', 'album')
    search_fields = ('caption', 'album__title', 'uploaded_by__username')
    readonly_fields = ('uploaded_at',)
