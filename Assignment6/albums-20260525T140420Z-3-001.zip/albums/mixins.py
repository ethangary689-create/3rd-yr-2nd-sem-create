"""
RBAC mixins for access control.

Roles:
  - Admin (staff/superuser): Full access to all albums and photos.
  - Standard User: Can only modify/delete their own content.
"""

from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.core.exceptions import PermissionDenied


class OwnerOrAdminRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """
    Grants access only if the current user is the owner of the object
    or is a staff/superuser (admin).
    
    The view must operate on an object with an `owner` attribute
    (for Album) or an `uploaded_by` attribute (for Photo).
    """

    def test_func(self):
        obj = self.get_object()
        user = self.request.user

        # Admins always have access
        if user.is_staff or user.is_superuser:
            return True

        # Check ownership — Album has 'owner', Photo has 'uploaded_by'
        if hasattr(obj, 'owner'):
            return obj.owner == user
        if hasattr(obj, 'uploaded_by'):
            return obj.uploaded_by == user

        return False

    def handle_no_permission(self):
        if self.request.user.is_authenticated:
            raise PermissionDenied("You do not have permission to perform this action.")
        return super().handle_no_permission()


class AlbumOwnerOrAdminMixin(LoginRequiredMixin, UserPassesTestMixin):
    """
    For views that operate on a Photo but need to check the parent Album's owner.
    Used for uploading photos to an album — checks that the user owns the album
    or is an admin.
    """

    def test_func(self):
        from .models import Album
        user = self.request.user

        if user.is_staff or user.is_superuser:
            return True

        album_pk = self.kwargs.get('album_pk')
        if album_pk:
            try:
                album = Album.objects.get(pk=album_pk)
                return album.owner == user
            except Album.DoesNotExist:
                return False

        return False

    def handle_no_permission(self):
        if self.request.user.is_authenticated:
            raise PermissionDenied("You do not have permission to add photos to this album.")
        return super().handle_no_permission()
