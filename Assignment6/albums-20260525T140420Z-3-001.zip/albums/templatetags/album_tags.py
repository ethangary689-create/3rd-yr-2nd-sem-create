from django import template

register = template.Library()


@register.filter
def cloudinary_url(image, options=''):
    """
    Returns the Cloudinary URL for an image field.
    Usage: {{ photo.image|cloudinary_url }}
    With transformations: {{ photo.image|cloudinary_url:"w_400,h_300,c_fill" }}
    """
    if not image:
        return ''
    url = image.url if hasattr(image, 'url') else str(image)
    if options and '/upload/' in url:
        url = url.replace('/upload/', f'/upload/{options}/')
    return url
