/**
 * PhotoAlbum — Main JavaScript
 * Micro-interactions and UX enhancements
 */

document.addEventListener('DOMContentLoaded', () => {
    // =========================================================================
    // Auto-dismiss alerts after 5 seconds
    // =========================================================================
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) {
                alert.classList.add('fade-out');
                setTimeout(() => bsAlert.close(), 300);
            }
        }, 5000);
    });

    // =========================================================================
    // Navbar shrink on scroll
    // =========================================================================
    const navbar = document.querySelector('.glass-nav');
    if (navbar) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navbar.style.padding = '0.4rem 0';
                navbar.style.background = 'rgba(10, 14, 23, 0.95)';
            } else {
                navbar.style.padding = '0.8rem 0';
                navbar.style.background = 'rgba(10, 14, 23, 0.85)';
            }
        });
    }

    // =========================================================================
    // Staggered card animation on scroll
    // =========================================================================
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                entry.target.style.animationDelay = `${index * 0.1}s`;
                entry.target.classList.add('animate-fade-in-up');
                entry.target.style.opacity = '1';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    document.querySelectorAll('.album-card, .feature-card, .photo-card').forEach(card => {
        card.style.opacity = '0';
        observer.observe(card);
    });

    // =========================================================================
    // Form submit loading state
    // =========================================================================
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', () => {
            const btn = form.querySelector('[type="submit"]');
            if (btn && !btn.disabled) {
                btn.disabled = true;
                const originalHTML = btn.innerHTML;
                btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status"></span>Processing...';

                // Re-enable after 10s as fallback
                setTimeout(() => {
                    btn.disabled = false;
                    btn.innerHTML = originalHTML;
                }, 10000);
            }
        });
    });
});
